For use it, replace in Engine.u

[Fonts]
LargeFont=Engine.LargeFont

to

[Fonts]
LargeFont=xLargeFonts.xLargeFont