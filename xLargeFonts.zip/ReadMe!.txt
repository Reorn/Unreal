LargeFonts with small letters, accents, cyrillic and Greek letters
For use it, replace in Engine.int (or your localizatiion file)

[Fonts]
LargeFont=Engine.LargeFont

to

[Fonts]
LargeFont=xLargeFonts.xLargeFont

