﻿Correct Unicode fonts for Russian/Portuguese localization.
1) All letters that are in the original fonts
2) Аccents added to LargeFont (ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖ×ØÙÚÛÜÝÞß)
3) Cyrillic letters added to LargeFont, MediumFont, WhiteFont, and SmallFont
4) LargeFont has only capital letters, as original
5) Minimal size (no other/unused unicode symbols)

For Russian localization
Replace in Engine.rut:

[Fonts]
SmallFont=UniFonts.NewSmallFont
WhiteFont=UniFonts.NewWhiteFont
MedFont=UniFonts.NewMedFont
LargeFont=UniFonts.NewLargeFont
BigFont=UniFonts.NewMedFont

For Portuguese localization
Replace in Engine.ptt:

[Fonts]
SmallFont=UniFonts.NewSmallFont
WhiteFont=UniFonts.NewWhiteFont
MedFont=UniFonts.NewMedFont
LargeFont=UniFonts.NewLargeFont
BigFont=Engine.BigFont

